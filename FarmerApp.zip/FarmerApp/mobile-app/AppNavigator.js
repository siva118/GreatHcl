// AppNavigator.js
import { createAppContainer } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';
import LoginScreen from './screens/LoginScreen';
import HomeScreen from './screens/HomeScreen';
import SeedsScreen from './screens/SeedsScreen';
import MedicinesScreen from './screens/MedicinesScreen';
import AttendanceScreen from './screens/AttendanceScreen';
import ExpensesScreen from './screens/ExpensesScreen';
import WeatherScreen from './screens/WeatherScreen';
import CalendarScreen from './screens/CalendarScreen';

const AppNavigator = createStackNavigator(
  {
    Login: LoginScreen,
    Home: HomeScreen,
    Seeds: SeedsScreen,
    Medicines: MedicinesScreen,
    Attendance: AttendanceScreen,
    Expenses: ExpensesScreen,
    Weather: WeatherScreen,
    Calendar: CalendarScreen,
  },
  {
    initialRouteName: 'Login',  // Default screen when app launches
  }
);

export default createAppContainer(AppNavigator);
