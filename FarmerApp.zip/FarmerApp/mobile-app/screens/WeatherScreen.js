// screens/WeatherScreen.js
import React from 'react';
import { View, Text } from 'react-native';

const WeatherScreen = () => {
  return (
    <View style={{ flex: 1, padding: 20 }}>
      <Text>Weather Information (Example)</Text>
      {/* You can add your weather API fetching logic here */}
    </View>
  );
};

export default WeatherScreen;
