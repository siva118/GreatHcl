// screens/AttendanceScreen.js
import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, FlatList } from 'react-native';
import axios from 'axios';

const AttendanceScreen = () => {
  const [workerName, setWorkerName] = useState('');
  const [attendanceDate, setAttendanceDate] = useState('');
  const [attendanceList, setAttendanceList] = useState([]);

  useEffect(() => {
    axios.get('http://127.0.0.1:5000/attendance')
      .then(response => setAttendanceList(response.data))
      .catch(error => console.log(error));
  }, []);

  const addAttendance = () => {
    if (workerName && attendanceDate) {
      const attendance = { worker_name: workerName, attendance_date: attendanceDate };
      axios.post('http://127.0.0.1:5000/attendance', attendance)
        .then(response => {
          setAttendanceList([...attendanceList, response.data]);
        })
        .catch(error => console.log(error));

      setWorkerName('');
      setAttendanceDate('');
    }
  };

  return (
    <View style={{ flex: 1, padding: 20 }}>
      <Text>Worker Name:</Text>
      <TextInput
        style={{ height: 40, borderColor: 'gray', borderWidth: 1 }}
        onChangeText={setWorkerName}
        value={workerName}
      />
      <Text>Attendance Date:</Text>
      <TextInput
        style={{ height: 40, borderColor: 'gray', borderWidth: 1 }}
        onChangeText={setAttendanceDate}
        value={attendanceDate}
      />
      <Button title="Add Attendance" onPress={addAttendance} />
      <FlatList
        data={attendanceList}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => (
          <View>
            <Text>{item.worker_name} - {item.attendance_date}</Text>
          </View>
        )}
      />
    </View>
  );
};

export default AttendanceScreen;
