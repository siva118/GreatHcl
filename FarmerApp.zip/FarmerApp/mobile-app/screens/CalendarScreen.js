// screens/CalendarScreen.js
import React from 'react';
import { View, Text } from 'react-native';

const CalendarScreen = () => {
  return (
    <View style={{ flex: 1, padding: 20 }}>
      <Text>Calendar Information (Example)</Text>
      {/* You can integrate a calendar component here */}
    </View>
  );
};

export default CalendarScreen;
