// screens/HomeScreen.js
import React from 'react';
import { View, Text, Button } from 'react-native';

const HomeScreen = ({ navigation }) => {
  return (
    <View style={{ flex: 1, padding: 20 }}>
      <Text>Welcome to the Farmer's App!</Text>
      <Button title="View Seeds" onPress={() => navigation.navigate('Seeds')} />
      <Button title="View Medicines" onPress={() => navigation.navigate('Medicines')} />
      <Button title="View Attendance" onPress={() => navigation.navigate('Attendance')} />
      <Button title="View Expenses" onPress={() => navigation.navigate('Expenses')} />
      <Button title="View Weather" onPress={() => navigation.navigate('Weather')} />
      <Button title="View Calendar" onPress={() => navigation.navigate('Calendar')} />
    </View>
  );
};

export default HomeScreen;
