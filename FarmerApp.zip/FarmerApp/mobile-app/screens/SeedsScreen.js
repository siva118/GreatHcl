// screens/SeedsScreen.js
import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, Button } from 'react-native';
import axios from 'axios';

const SeedsScreen = () => {
  const [seeds, setSeeds] = useState([]);

  useEffect(() => {
    axios.get('http://127.0.0.1:5000/seeds')
      .then(response => setSeeds(response.data))
      .catch(error => console.log(error));
  }, []);

  return (
    <View style={{ flex: 1, padding: 20 }}>
      <Text>Seeds Information</Text>
      <FlatList
        data={seeds}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => (
          <View>
            <Text>{item.seed_name} ({item.seed_type})</Text>
          </View>
        )}
      />
    </View>
  );
};

export default SeedsScreen;
