// screens/LoginScreen.js
import React, { useState } from 'react';
import { View, Text, TextInput, Button } from 'react-native';
import axios from 'axios';

const LoginScreen = ({ navigation }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const login = () => {
    axios.post('http://127.0.0.1:5000/login', { username, password })
      .then(response => {
        alert(response.data.message);
        if (response.data.message === "Login successful") {
          navigation.navigate('Home');
        }
      })
      .catch(error => {
        alert("Error: Invalid credentials");
      });
  };

  return (
    <View style={{ flex: 1, padding: 20 }}>
      <Text>Username:</Text>
      <TextInput
        style={{ height: 40, borderColor: 'gray', borderWidth: 1 }}
        onChangeText={setUsername}
        value={username}
      />
      <Text>Password:</Text>
      <TextInput
        style={{ height: 40, borderColor: 'gray', borderWidth: 1 }}
        secureTextEntry
        onChangeText={setPassword}
        value={password}
      />
      <Button title="Login" onPress={login} />
    </View>
  );
};

export default LoginScreen;
