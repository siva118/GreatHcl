// screens/ExpensesScreen.js
import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, Button } from 'react-native';
import axios from 'axios';

const ExpensesScreen = () => {
  const [expenses, setExpenses] = useState([]);

  useEffect(() => {
    axios.get('http://127.0.0.1:5000/expenses')
      .then(response => setExpenses(response.data))
      .catch(error => console.log(error));
  }, []);

  return (
    <View style={{ flex: 1, padding: 20 }}>
      <Text>Expenses Information</Text>
      <FlatList
        data={expenses}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => (
          <View>
            <Text>{item.expense_name} - {item.expense_amount} on {item.expense_date}</Text>
          </View>
        )}
      />
    </View>
  );
};

export default ExpensesScreen;
