# app.py
from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from models import db, User, Seed, Medicine, Attendance, Expense, Weather, Calendar
import datetime

app = Flask(__name__)

# Configure the database URI
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///farmers_app.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize the database
db.init_app(app)

@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data['username']
    password = data['password']
    
    # Check if the user exists in the database
    user = User.query.filter_by(username=username, password=password).first()
    
    if user:
        return jsonify({'message': 'Login successful'}), 200
    else:
        return jsonify({'message': 'Invalid credentials'}), 401

@app.route('/seeds', methods=['GET'])
def get_seeds():
    seeds = Seed.query.all()
    seeds_list = [{'seed_name': seed.name, 'seed_type': seed.type} for seed in seeds]
    return jsonify(seeds_list)

@app.route('/seeds', methods=['POST'])
def add_seed():
    data = request.get_json()
    seed_name = data['seed_name']
    seed_type = data['seed_type']
    
    new_seed = Seed(name=seed_name, type=seed_type)
    db.session.add(new_seed)
    db.session.commit()
    
    return jsonify({'message': 'Seed added successfully'}), 201

@app.route('/medicines', methods=['GET'])
def get_medicines():
    medicines = Medicine.query.all()
    medicines_list = [{'medicine_name': medicine.name, 'medicine_type': medicine.type} for medicine in medicines]
    return jsonify(medicines_list)

@app.route('/medicines', methods=['POST'])
def add_medicine():
    data = request.get_json()
    medicine_name = data['medicine_name']
    medicine_type = data['medicine_type']
    
    new_medicine = Medicine(name=medicine_name, type=medicine_type)
    db.session.add(new_medicine)
    db.session.commit()
    
    return jsonify({'message': 'Medicine added successfully'}), 201

@app.route('/attendance', methods=['GET'])
def get_attendance():
    attendance = Attendance.query.all()
    attendance_list = [{'worker_name': att.worker_name, 'attendance_date': att.attendance_date} for att in attendance]
    return jsonify(attendance_list)

@app.route('/attendance', methods=['POST'])
def add_attendance():
    data = request.get_json()
    worker_name = data['worker_name']
    attendance_date = data['attendance_date']
    
    new_attendance = Attendance(worker_name=worker_name, attendance_date=attendance_date)
    db.session.add(new_attendance)
    db.session.commit()
    
    return jsonify({'message': 'Attendance added successfully'}), 201

@app.route('/expenses', methods=['GET'])
def get_expenses():
    expenses = Expense.query.all()
    expenses_list = [{'expense_name': exp.name, 'expense_amount': exp.amount, 'expense_date': exp.date} for exp in expenses]
    return jsonify(expenses_list)

@app.route('/expenses', methods=['POST'])
def add_expense():
    data = request.get_json()
    expense_name = data['expense_name']
    expense_amount = data['expense_amount']
    expense_date = data['expense_date']
    
    new_expense = Expense(name=expense_name, amount=expense_amount, date=expense_date)
    db.session.add(new_expense)
    db.session.commit()
    
    return jsonify({'message': 'Expense added successfully'}), 201

@app.route('/weather', methods=['GET'])
def get_weather():
    # Example static weather data. You can replace this with actual weather API
    weather_data = {
        "best_weather_for_paddy_sowing": "Clear and warm weather (20°C to 30°C)"
    }
    return jsonify(weather_data)

@app.route('/calendar', methods=['GET'])
def get_calendar():
    # Example static calendar data. You can replace this with actual events
    calendar_data = {
        "tasks": [
            {"task": "Sowing", "date": "2025-05-01"},
            {"task": "Watering", "date": "2025-05-05"},
        ]
    }
    return jsonify(calendar_data)

@app.route('/weather', methods=['POST'])
def add_weather():
    data = request.get_json()
    weather_condition = data['weather_condition']
    
    new_weather = Weather(condition=weather_condition)
    db.session.add(new_weather)
    db.session.commit()
    
    return jsonify({'message': 'Weather information added successfully'}), 201

@app.route('/calendar', methods=['POST'])
def add_calendar_event():
    data = request.get_json()
    event_task = data['task']
    event_date = data['date']
    
    new_event = Calendar(task=event_task, date=event_date)
    db.session.add(new_event)
    db.session.commit()
    
    return jsonify({'message': 'Calendar event added successfully'}), 201

if __name__ == '__main__':
    app.run(debug=True)
