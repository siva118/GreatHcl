# models.py
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False)

    def __repr__(self):
        return f'<User {self.username}>'

class Seed(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    type = db.Column(db.String(100), nullable=False)

    def __repr__(self):
        return f'<Seed {self.name}>'

class Medicine(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    type = db.Column(db.String(100), nullable=False)

    def __repr__(self):
        return f'<Medicine {self.name}>'

class Attendance(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    worker_name = db.Column(db.String(100), nullable=False)
    attendance_date = db.Column(db.String(100), nullable=False)

    def __repr__(self):
        return f'<Attendance {self.worker_name} on {self.attendance_date}>'

class Expense(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    date = db.Column(db.String(100), nullable=False)

    def __repr__(self):
        return f'<Expense {self.name} - {self.amount}>'

class Weather(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    condition = db.Column(db.String(200), nullable=False)

    def __repr__(self):
        return f'<Weather {self.condition}>'

class Calendar(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    task = db.Column(db.String(100), nullable=False)
    date = db.Column(db.String(100), nullable=False)

    def __repr__(self):
        return f'<Calendar Event {self.task} on {self.date}>'

