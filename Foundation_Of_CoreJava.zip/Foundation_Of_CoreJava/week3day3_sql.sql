#1. How many females and how many male passengers traveled for a minimum distance of 600 KM s?
select count(*),Gender 
from passenger
where  Distance >= 600
group by gender;
#2. Find the minimum ticket price for Sleeper Bus.
select min(price),Bus_Type
from price
where Bus_Type='sleeper';
#3. Select passenger names whose names start with character 'S'
select Passenger_name
from passenger
where Passenger_name like 'S%';
#4. Calculate price charged for each passenger displaying Passenger name, Boarding City, Destination City,
#Bus_Type, Price in the output
select distinct(Passenger_name),Boarding_City,Destination_City,e.Bus_Type,e.Price from
passenger p,price e
where p.Distance=e.Distance and p.Bus_Type=e.Bus_Type;
#5. What is the passenger name and his/her ticket price who travelled in Sitting bus for a distance of 1000
#KM s
select price from price
where Bus_Type='sitting' and Distance=1000;
#6. What will be the Sitting and Sleeper bus charge for Pallavi to travel from Bangalore to Panaji?
select price
from price
where  Distance=(select Distance
				from passenger
				where Passenger_name='pallavi')
group by Bus_Type;
#7. List the distances from the "Passenger" table which are unique (non-repeated distances) in descending
#order.
select distinct(Distance)
from passenger
order by -Distance;
#8. Display the passenger name and percentage of distance travelled by that passenger from the total
#distance travelled by all passengers without using user variables
select passenger_name,(Distance/sum(distance))*100 as percentage
from passenger;

                                        
